import java.util.ArrayList;
import java.util.Calendar;

public class Election {

	private boolean isFinished;
	private String name, electionDescription;
	private int electionCommissioner, electionType, //0 - Single Ballot 1 - Multiple Ballot 
	whoCanVote; //0 - Full Time Students 1 - All Students 2 - College Specific 3 - Class Rank Specific
	private ArrayList<Candidate> candidates;
	private ArrayList<Vote> votes;
	private Calendar calendar;
	private int college;
	
	public Election(String name, int electionCommissioner)
	{
		isFinished = false;
		this.name = name;
		this.electionCommissioner = electionCommissioner;
		candidates = new ArrayList<Candidate>();
		votes = new ArrayList<Vote>();
	}
	
	public void setData(Calendar duration, String electionDescription, int electionType, int whoCanVote, int college)
	{
		votes = new ArrayList<Vote>();
		calendar = duration;
		this.electionDescription = electionDescription;
		this.electionType = electionType;
		this.whoCanVote = whoCanVote;
		isFinished = true;
		this.college = college;
	}
	
	public String getElectionName()
	{
		return name;
	}
	
	public int getCollege()
	{
		return college;
	}
	
	public boolean canFinish()
	{
		return !isFinished;
	}

	public String getDescription()
	{
		return electionDescription;
	}
	
	public void addCandidate(Candidate c)
	{
		candidates.add(c);
	}
	
	public void removeCandidate(Candidate c)
	{
		candidates.remove(c);
	}

	public ArrayList<Candidate> getCandidates() {
		return candidates;
	}
	
	public void submitVote(Vote v)
	{
		votes.add(v);
	}
	
}
