import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JList;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import javax.swing.UIManager;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.AbstractListModel;
import javax.swing.DefaultListModel;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.JLabel;
import java.awt.Toolkit;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;

import java.awt.ScrollPane;
import javax.swing.ScrollPaneConstants;

public class ElectionMain extends JFrame {

	private JPanel contentPane;
	private ArrayList<Election> elections;
	private static String[] colleges = {"Math", "Science", "English", "Arts", "Engineering"};
	private ArrayList<Student> students;
	private int yourself;
	
	/**
	 * Create the frame.
	 */
	public ElectionMain() {
		
		elections = new ArrayList<Election>();
		
		Student studentOne = new Student(91834, "Other", "John Wilks Booth", 3, "Gender Studies", "White", 2, 0);
		Student studentTwo = new Student(32141, "Male", "Willam Turner", 4, "Computer Science", "Black", 1, 0);
		Student studentThree = new Student(38495, "Female", "Shinequa ", 3, "English", "Asian", 4, 3);
		Student studentFour = new Student(32942, "Male", "Billy Bob", 1, "Biology", "Hispanic", 1, 0);
		
		students = new ArrayList<Student>();
		
		students.add(studentOne);
		students.add(studentTwo);
		students.add(studentThree);
		students.add(studentFour);
		
		
		setResizable(false);
		setFont(new Font("Arial", Font.PLAIN, 18));
		setIconImage(Toolkit.getDefaultToolkit().getImage(ElectionMain.class.getResource("/images/Deku_Link_Artwork.png")));
		setTitle("Election System 1.0");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 975, 782);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setForeground(new Color(255, 255, 255));
		menuBar.setBackground(new Color(105, 105, 105));
		setJMenuBar(menuBar);
		
		JMenu mnFile = new JMenu("File");
		mnFile.setForeground(new Color(255, 255, 255));
		mnFile.setBackground(new Color(105, 105, 105));
		mnFile.setFont(new Font("Arial", Font.PLAIN, 18));
		menuBar.add(mnFile);
		
		JMenuItem mntmQuit = new JMenuItem("Quit");
		mntmQuit.setFont(new Font("Arial", Font.PLAIN, 18));
		mnFile.add(mntmQuit);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 128, 0));
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Student Options", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(12, 565, 620, 131);
		contentPane.add(panel);
		panel.setLayout(null);
		
		
		
		
		JButton btnViewResults = new JButton("View Results");
		btnViewResults.setBounds(258, 29, 125, 25);
		panel.add(btnViewResults);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 128, 0));
		panel_1.setBorder(new TitledBorder(null, "Administrative Actions", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(644, 565, 301, 131);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		
		
		JButton btnStartRecount = new JButton("Start Recount");
		btnStartRecount.setBounds(12, 61, 143, 25);
		panel_1.add(btnStartRecount);
		
		JButton btnDisqualifyAVote = new JButton("Disqualify a vote");
		btnDisqualifyAVote.setBounds(161, 61, 126, 25);
		panel_1.add(btnDisqualifyAVote);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 128, 0));
		panel_2.setBorder(new TitledBorder(null, "Your Account Details", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_2.setBounds(659, 13, 286, 383);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblName = new JLabel("Name: " + students.get(yourself).getName());
		lblName.setFont(new Font("Arial", Font.PLAIN, 18));
		lblName.setBounds(12, 33, 262, 35);
		panel_2.add(lblName);
		
		JLabel lblGender = new JLabel("Gender: " + students.get(yourself).getGender());
		lblGender.setFont(new Font("Arial", Font.PLAIN, 18));
		lblGender.setBounds(12, 81, 262, 35);
		panel_2.add(lblGender);
		
		JLabel lblMajor = new JLabel("Major:" + students.get(yourself).getMajor());
		lblMajor.setFont(new Font("Arial", Font.PLAIN, 18));
		lblMajor.setBounds(12, 129, 262, 35);
		panel_2.add(lblMajor);
		
		JLabel lblAge = new JLabel("Student ID: " + students.get(yourself).getId());
		lblAge.setFont(new Font("Arial", Font.PLAIN, 18));
		lblAge.setBounds(12, 177, 262, 35);
		panel_2.add(lblAge);
		
		JLabel lblYear = new JLabel("Year: " + students.get(yourself).getYear());
		lblYear.setFont(new Font("Arial", Font.PLAIN, 18));
		lblYear.setBounds(12, 225, 262, 35);
		panel_2.add(lblYear);
		
		JLabel lblAccountType = new JLabel("Account Type: " + students.get(yourself).getType());
		
		lblAccountType.setFont(new Font("Arial", Font.PLAIN, 18));
		lblAccountType.setBounds(12, 321, 262, 35);
		panel_2.add(lblAccountType);
		
		JLabel lblSystemTime = new JLabel("System Time:");
		lblSystemTime.setFont(new Font("Arial", Font.PLAIN, 18));
		lblSystemTime.setVerticalAlignment(SwingConstants.TOP);
		lblSystemTime.setBounds(659, 424, 264, 42);
		contentPane.add(lblSystemTime);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setSize(620, 520);
		scrollPane.setLocation(12, 13);
		contentPane.add(scrollPane);
		DefaultListModel actList = new DefaultListModel();
		JList list = new JList(actList);
		scrollPane.setViewportView(list);
		
		JButton btnCreateElection = new JButton("Create Election");
		btnCreateElection.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CreateElection crea = new CreateElection();
				crea.setVisible(true);
				crea.getCreateButton().addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						for(int i = 0; i < list.getModel().getSize(); i++)
						{
							if(actList.getElementAt(i).toString().toLowerCase().equals(crea.getElectionName().toLowerCase()))
							{
								JOptionPane.showMessageDialog(crea.getOwner(), "This Election Already Exists", "Cannot Create Election", JOptionPane.ERROR_MESSAGE);
								return;
							}
							else if(crea.getElectionName().equals("") || crea.getElectionCommissioner().equals("") || !crea.getElectionCommissioner().matches("[0-9]+"))
							{
								JOptionPane.showMessageDialog(crea.getOwner(), "You Need an Election Name &\nan Election Commissioner ID (is a number)", "Cannot Create Election", JOptionPane.ERROR_MESSAGE);
								return;
							}
						}
						actList.addElement(crea.getElectionName());
						Election temp = new Election(crea.getElectionName(), Integer.parseInt(crea.getElectionCommissioner()));
						elections.add(temp);
						crea.dispose();
					}
				});
			}
		});
		
		JButton btnViewStats = new JButton("View Statistics");
		btnViewStats.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(!list.isSelectionEmpty())
				{
					ViewStatistics stats;
					try {
						stats = new ViewStatistics();
						stats.setVisible(true);
						stats.getElectionName().setText(list.getSelectedValue().toString());
					} catch (IOException e) {
						e.printStackTrace();
					}
				 return;
				}
				JOptionPane.showMessageDialog(contentPane, "You have not selected a valid Election", "Error", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnViewStats.setBounds(121, 29, 125, 25);
		panel.add(btnViewStats);
		
		JButton btnVoteIn = new JButton("Vote In");
		btnVoteIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//check to see if you can vote (right account type/is an ongoing election/haven't exceeded the number of times you can can vote)
				//get election details
				//ALL OF THESE SHOULD BE CHECKED IN THE IF STATEMENT BELOW THIS LINE
				if(!list.isSelectionEmpty())
				{
					int currentElectionID = -1;
					for(Election e: elections)
					{
						if(e.getElectionName().equals(list.getSelectedValue().toString()))
						{
							currentElectionID = elections.indexOf(e);
						}
					}
					System.out.print(currentElectionID);
					BallotScreen ballot = new BallotScreen(elections.get(currentElectionID)); //some constructor in the BallotScreen class will store necessary data.
					ballot.setVisible(true);
					ballot.getCastBallotButton().addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
							if(!ballot.canCast())
							{
								JOptionPane.showMessageDialog(ballot.getOwner(), "You have not selected a candidate", "Cannot Cast Ballot", JOptionPane.ERROR_MESSAGE);
								return;
							}
							//decrement the user's castable ballots for this election somehow
							//push the user's demographics and candidate selection as a valid vote to the server
							int currentElectionID = -1;
							for(Election ee: elections)
							{
								if(ee.getElectionName().equals(list.getSelectedValue().toString()))
								{
									currentElectionID = elections.indexOf(ee);
								}
							}
							for(Candidate cand: elections.get(currentElectionID).getCandidates())
							{
								if(cand.getName().equals(ballot.getList().getSelectedValue()))
								{
									elections.get(currentElectionID).submitVote(new Vote(yourself, cand));
								}
							}
							ballot.dispose();
						}
					});
					return;
				}
				JOptionPane.showMessageDialog(contentPane, "You have not selected a valid Election", "Error", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnVoteIn.setBounds(12, 29, 97, 25);
		panel.add(btnVoteIn);
		
		btnCreateElection.setBounds(12, 30, 143, 25);
		panel_1.add(btnCreateElection);
		
		JButton btnContinueCreation = new JButton("Cont. Creation [EC]");
		btnContinueCreation.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//CHECK IF THE ELECTION HAS NOT BEEN FINISHED YET  && IF THIS ELECTION COMMISSIONER ACCOUNT ID IS VALID FOR THE ELECTION
				
				if(!list.isSelectionEmpty())
				{
					int currentElectionID = -1;
					for(Election ee: elections)
					{
						if(ee.getElectionName().equals(list.getSelectedValue().toString()))
						{
							currentElectionID = elections.indexOf(ee);
						}
					}
					if(elections.get(currentElectionID).canFinish())
					{		
					ContinueCreateElection createContinue = new ContinueCreateElection(students, elections.get(currentElectionID));
					createContinue.setElectionName(list.getSelectedValue().toString());
					createContinue.setVisible(true);
					createContinue.getFinish().addActionListener(new ActionListener(){
						public void actionPerformed(ActionEvent arg0) {
							if(!createContinue.canFinish())
							{
								JOptionPane.showMessageDialog(createContinue.getOwner(), "One or more fields are invalid.\nNote: An election's length must be at least one minute long.", "Cannot Create Election", JOptionPane.ERROR_MESSAGE);
								return;
							}
							//SET THE ELECTION TO FINISHED STATE SO YOU CAN NO LONGER EDIT IT
							int currentElectionID = -1;
							for(Election ee: elections)
							{
								if(ee.getElectionName().equals(list.getSelectedValue().toString()))
								{
									currentElectionID = elections.indexOf(ee);
								}
							}
							elections.get(currentElectionID).setData(createContinue.getCalendar(), createContinue.getDescription(), createContinue.getTypeElection(),
											createContinue.getElectionVote(), createContinue.getCollege()); //Need Candidate Class
							
							createContinue.dispose();
						}
					});
					return;
					}
				}
				JOptionPane.showMessageDialog(contentPane, "You have not selected a valid Election\nOr this election has already been created", "Error", JOptionPane.ERROR_MESSAGE);
			}
		});
		btnContinueCreation.setBounds(12, 93, 143, 25);
		panel_1.add(btnContinueCreation);
		
		JButton btnRequalifyAVote = new JButton("Requalify a vote");
		btnRequalifyAVote.setBounds(161, 93, 126, 25);
		panel_1.add(btnRequalifyAVote);
		
		Timer time = new Timer(1000, new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
				Date date = new Date();
				lblSystemTime.setText("System Time: " + dateFormat.format(date));
			}
			
		});
		time.start();
		
	}
	
	
	public void setStudentSelf(int num)
	{
		yourself = num;
	}
	
	public ArrayList<Student> getStudents()
	{
		return students;
	}
}
