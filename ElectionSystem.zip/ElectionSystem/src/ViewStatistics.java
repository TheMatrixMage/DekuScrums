import java.awt.EventQueue;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import org.knowm.xchart.BitmapEncoder;
import org.knowm.xchart.PieChart;
import org.knowm.xchart.PieChartBuilder;
import org.knowm.xchart.style.PieStyler.AnnotationType;
import org.knowm.xchart.style.Styler.ChartTheme;

import java.awt.Toolkit;
import java.io.IOException;
import java.util.ArrayList;
import java.awt.Dimension;
import javax.swing.JLabel;
import javax.swing.ScrollPaneConstants;

public class ViewStatistics extends JFrame {

	private JPanel contentPane;
	private JLabel lblElectionName;
	private ArrayList<String> candidates;
	private ArrayList<String> demographics;
	/**
	 * Create the View Statistics frame.
	 */
	public ViewStatistics() throws IOException {
		//GRAB demographics and candidates from server;
		
		setResizable(false);
		setTitle("View Statistics");
		setIconImage(Toolkit.getDefaultToolkit().getImage(ViewStatistics.class.getResource("/images/Deku_Link_Artwork.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 708, 579);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPaneStatistics = new JScrollPane();
		scrollPaneStatistics.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPaneStatistics.setBounds(10, 33, 670, 500);
		contentPane.add(scrollPaneStatistics);
		
		
		PieChart[] charts = new PieChart[5];
		for(int i = 0; i < charts.length; i++)
		{
			PieChart chart = new PieChartBuilder().width(650).height(500).title("Chart " + i).theme(ChartTheme.GGPlot2).build();
			chart.getStyler().setLegendVisible(false);
		    chart.getStyler().setAnnotationType(AnnotationType.LabelAndPercentage);
		    chart.getStyler().setAnnotationDistance(1.15);
		    chart.getStyler().setPlotContentSize(.7);
		    chart.getStyler().setStartAngleInDegrees(90);
		    int r = (int)(Math.random()*100);
			for(int c = 0; c < 2; c++)//FOR LOOP TO LOOP THE CANDIDATE[] for every candidate
			{
				switch(c)
				{
					case 0:
						chart.addSeries("Candidate 1", r);
						break;
					case 1:
						chart.addSeries("Candidate 2", 100-r);
						break;
				}
			}
			charts[i] = chart;
		}
		JPanel panel = new JPanel(){
			@Override
		    protected void paintComponent(Graphics g) {
		        super.paintComponent(g);
		        for(int i = 0; i < charts.length; i++)
		        {
		        	g.drawImage(BitmapEncoder.getBufferedImage(charts[i]), 0, (i*500), this);
		        }
		    }
		};
		panel.setPreferredSize(new Dimension(650, 500*charts.length));
		scrollPaneStatistics.setViewportView(panel);
		
		
		
		lblElectionName = new JLabel("ElectionName");
		lblElectionName.setBounds(10, 4, 95, 16);
		contentPane.add(lblElectionName);
	}
	public JLabel getElectionName()
	{
		return lblElectionName;
	}
	
}
