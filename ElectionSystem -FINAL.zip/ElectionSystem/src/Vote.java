import java.util.ArrayList;

public class Vote
{
	
	int sIDs; //ID of the student
	Candidate candidate;
	

	public Vote(int sID, Candidate candidate)
	{
		sIDs = sID;
		this.candidate = candidate;
	}
}