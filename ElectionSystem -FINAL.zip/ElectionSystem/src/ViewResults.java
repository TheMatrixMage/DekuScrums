import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.border.EmptyBorder;

import org.knowm.xchart.BitmapEncoder;
import org.knowm.xchart.PieChart;
import org.knowm.xchart.PieChartBuilder;
import org.knowm.xchart.style.PieStyler.AnnotationType;
import org.knowm.xchart.style.Styler.ChartTheme;

import java.awt.Toolkit;

public class ViewResults extends JFrame {

	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public ViewResults(Election e) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(ViewResults.class.getResource("/images/Deku_Link_Artwork.png")));
		setTitle("Results");
		setIconImage(Toolkit.getDefaultToolkit().getImage(ViewStatistics.class.getResource("/images/Deku_Link_Artwork.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 708, 579);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPaneStatistics = new JScrollPane();
		scrollPaneStatistics.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPaneStatistics.setBounds(10, 33, 670, 500);
		contentPane.add(scrollPaneStatistics);
		
		
			PieChart chart = new PieChartBuilder().width(650).height(500).title("Current Results").theme(ChartTheme.GGPlot2).build();
			chart.getStyler().setLegendVisible(false);
		    chart.getStyler().setAnnotationType(AnnotationType.LabelAndPercentage);
		    chart.getStyler().setAnnotationDistance(1.15);
		    chart.getStyler().setPlotContentSize(.7);
		    chart.getStyler().setStartAngleInDegrees(90);
			for(int c = 0; c < 2; c++)//FOR LOOP TO LOOP THE CANDIDATE[] for every candidate
			{
				switch(c)
				{
					case 0:
						chart.addSeries("Candidate 1", 60);
						break;
					case 1:
						chart.addSeries("Candidate 2", 40);
						break;
				}
			}
		JPanel panel = new JPanel(){
			@Override
		    protected void paintComponent(Graphics g) {
		        super.paintComponent(g);
		        	g.drawImage(BitmapEncoder.getBufferedImage(chart), 0, 0, this);
		    }
		};
		panel.setPreferredSize(new Dimension(650, 500));
		scrollPaneStatistics.setViewportView(panel);
		
		
		
		JLabel lblElectionName = new JLabel(e.getElectionName());
		lblElectionName.setBounds(10, 4, 95, 16);
		contentPane.add(lblElectionName);
	}

}
