import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import java.awt.ScrollPane;
import javax.swing.UIManager;
import java.awt.Color;
import javax.swing.JTextPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.Timer;
import javax.swing.JList;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class BallotScreen extends JFrame {

	private JPanel contentPane;
	private JButton btnCastBallot;
	private JScrollPane scrollPaneCandidates;
	private JList list;
	private Vote ballot;

	/**
	 * Create the Ballot Screen frame.
	 */
	public BallotScreen(Election e) {
		setResizable(false);
		setTitle("Cast Ballot");
		setIconImage(Toolkit.getDefaultToolkit().getImage(BallotScreen.class.getResource("/images/Deku_Link_Artwork.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 578, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panelAvailableCandidates = new JPanel();
		panelAvailableCandidates.setBorder(new TitledBorder(null, "Available Candidates", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelAvailableCandidates.setBounds(12, 13, 312, 275);
		contentPane.add(panelAvailableCandidates);
		panelAvailableCandidates.setLayout(null);
		
		scrollPaneCandidates = new JScrollPane();
		scrollPaneCandidates.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPaneCandidates.setBounds(10, 20, 292, 242);
		panelAvailableCandidates.add(scrollPaneCandidates);
		
		DefaultListModel actList = new DefaultListModel();
		System.out.println(e.getCandidates().size());
		for(Candidate c: e.getCandidates())
		{
			actList.addElement(c.getName());
		}
		list = new JList(actList);
		scrollPaneCandidates.setViewportView(list);
		
		
		
		JPanel panelSelectedCandidateDetails = new JPanel();
		panelSelectedCandidateDetails.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "Selected Candidate Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panelSelectedCandidateDetails.setBounds(336, 13, 212, 275);
		contentPane.add(panelSelectedCandidateDetails);
		panelSelectedCandidateDetails.setLayout(null);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(12, 27, 188, 16);
		panelSelectedCandidateDetails.add(lblName);
		
		
		JLabel lblAffiliation = new JLabel("Affiliation:");
		lblAffiliation.setBounds(12, 86, 188, 16);
		panelSelectedCandidateDetails.add(lblAffiliation);
		
		Timer timer = new Timer(10, new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(list.getSelectedValue() != null)
				{
					for(Candidate c: e.getCandidates())
					{
						if(c.getName().equals(list.getSelectedValue().toString()))
						{
							lblName.setText("Name: " + list.getSelectedValue().toString());
							lblAffiliation.setText("Affiliation: " + c.getAffiliation());
						}
					}
				}
				
			}
		});
		timer.start();
		
		JPanel panelBallotDetails = new JPanel();
		panelBallotDetails.setBorder(new TitledBorder(null, "Ballot Details", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panelBallotDetails.setBounds(12, 290, 310, 150);
		contentPane.add(panelBallotDetails);
		panelBallotDetails.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 20, 280, 117);
		panelBallotDetails.add(scrollPane_1);
		
		JTextPane txtpnDetails = new JTextPane();
		txtpnDetails.setBackground(Color.ORANGE);
		scrollPane_1.setViewportView(txtpnDetails);
		txtpnDetails.setEditable(false);
		txtpnDetails.setText(e.getDescription() + " You can vote X amount of times. ");
		
		btnCastBallot = new JButton("Cast Ballot");
		btnCastBallot.setBounds(451, 415, 97, 25);
		contentPane.add(btnCastBallot);
	}
	
	public JButton getCastBallotButton()
	{
		return btnCastBallot;
	}
	
	public boolean canCast()
	{
		return !(list.isSelectionEmpty());
	}
	
	public JList getList()
	{
		return list;
	}
}
