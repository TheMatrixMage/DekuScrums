
public class Student 
{
	private int id, year;
	private String gender;
	private String name;
	private int college;
	private String major;
	private String race;
	private int type; // 0 - Student 1 - Election Commissioner 2 - Head of Student Orgs
	
	public Student(int id, String gender, String name, int college, String major, String race, int year, int type)
	{
		this.id = id;
		this.gender = gender;
		this.name = name;
		this.college = college;
		this.major = major;
		this.race = race;
		this.year = year;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public String getGender() {
		return gender;
	}

	public String getName() {
		return name;
	}

	public int getCollege() {
		return college;
	}

	public String getMajor() {
		return major;
	}

	public String getRace() {
		return race;
	}

	public int getYear() {
		return year;
	}

	public String getType() {
		String tp = "";
		switch(type)
		{
			case 0:
				tp = "Student";
				break;
			case 1:
				tp = "Election Commissioner";
				break;
			case 3:
				tp = "Head of Student Orgs";
				break;
		}
		return tp;
	}
	
	public int getTypee()
	{
		return type;
	}
	
	
}
