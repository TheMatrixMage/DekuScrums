
public class Candidate extends Student {

	private String affiliation;
	public Candidate(int id, String gender, String name, int college, String major, String race, int year, int type, String affiliation) 
	{
		super(id, gender, name, college, major, race, year, type);
		this.affiliation = affiliation;
	}
	
	public String getAffiliation() 
	{
		return affiliation;
	}
	
	

}
